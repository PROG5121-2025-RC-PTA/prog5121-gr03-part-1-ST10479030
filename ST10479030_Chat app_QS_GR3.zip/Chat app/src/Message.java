import org.json.simple.JSONObject;

import java.util.Random;

public class Message {
    private String messageID;
    private static int totalMessages = 0;
    private static int messageCount = 0;
    private String recipient;
    private String message;
    private String messageHash;

    public Message(String recipient, String message) {
        this.recipient = recipient;
        this.message = message;
        this.messageID = generateMessageID();
        this.messageHash = createMessageHash();
    }

    private String generateMessageID() {
        Random rand = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(rand.nextInt(10));
        }
        return id.toString();
    }

    public boolean checkMessageID() {
        return messageID.length() == 10;
    }

    public int checkRecipientCell() {
        if (recipient.length() <= 10 && recipient.startsWith("+")) {
            return 1; // valid
        }
        return 0; // invalid
    }

    public String createMessageHash() {
        String[] words = message.split(" ");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;

        return (messageID.substring(0, 2) + ":" + messageCount + ":" + firstWord + lastWord).toUpperCase();
    }

    public String sendMessageOption(String option) {
        switch (option) {
            case "1":
                totalMessages++;
                return "Message successfully sent.";
            case "2":
                return "Press 0 to delete message.";
            case "3":
                return storeMessage();
            default:
                return "Invalid option.";
        }
    }

    public String printMessage() {
        return "Message ID: " + messageID + "\n" +
               "Message Hash: " + messageHash + "\n" +
               "Recipient: " + recipient + "\n" +
               "Message: " + message;
    }

    public static int returnTotalMessages() {
        return totalMessages;
    }

    public String storeMessage() {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("MessageID", messageID);
        jsonObject.put("Recipient", recipient);
        jsonObject.put("Message", message);
        jsonObject.put("MessageHash", messageHash);

        JsonUtil.writeToFile(jsonObject);
        return "Message successfully stored.";
    }
}
