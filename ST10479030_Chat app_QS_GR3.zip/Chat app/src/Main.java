import java.util.Scanner;

public class Main {

    // Constants for validation messages and limits
    private static final String WELCOME_MESSAGE = "Welcome to the Registration System!";
    private static final String INVALID_PHONE_MESSAGE = "Invalid phone number format. Please try again.";
    private static final String INVALID_USERNAME_MESSAGE = "Invalid username. It must contain an underscore and be no more than five characters long.";
    private static final String INVALID_PASSWORD_MESSAGE = "Invalid password. It must have at least eight characters, a capital letter, a number, and a special character.";
    private static final int MAX_LOGIN_ATTEMPTS = 3;

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {

            // Step 1: Get user registration details ---
            System.out.println(WELCOME_MESSAGE);

            // Get first name
            String firstName = getInput(scanner, "Enter your first name: ", "First name cannot be empty. Please try again.", input -> !input.isEmpty());

            // Get last name
            System.out.print("Enter your last name: ");
            String lastName = scanner.nextLine().trim();

            // Get and validate phone number
            String phoneNumber = getInput(scanner, "Enter your South African phone number (e.g., +27680734690): ", INVALID_PHONE_MESSAGE, input -> input.matches("\\+27\\d{9}"));

            // Initialize Login instance with name and phone number
            Login login = new Login(firstName, lastName, phoneNumber);

            // Get and validate username
            String username = getInput(scanner, "Create a username: ", INVALID_USERNAME_MESSAGE, login::checkUserName);

            // Get and validate password
            String password = getInput(scanner, "Create a password: ", INVALID_PASSWORD_MESSAGE, login::checkPasswordComplexity);

            // --- Step 2: Register the user ---
            String registrationMessage = login.registerUser(username, password);
            System.out.println(registrationMessage);

            // Only proceed if registration was successful
            if (registrationMessage.equals("Registration successful!")) {
                // --- Step 3: Log in ---
                System.out.println("\nPlease log in.");
                handleLogin(scanner, login);
            } else {
                System.out.println("Registration failed. Please restart the program.");
            }

        } catch (Exception e) {
            System.err.println("An unexpected error occurred: " + e.getMessage());
        }
    }

    // The Helper method to get validated input
    private static String getInput(Scanner scanner, String prompt, String errorMessage, InputValidator validator) {
        String input;
        while (true) {
            System.out.print(prompt);
            input = scanner.nextLine().trim();
            if (validator.isValid(input)) {
                break;
            } else {
                System.out.println(errorMessage);
            }
        }
        return input;
    }

    // This Handles the login process
    private static void handleLogin(Scanner scanner, Login login) {
        boolean loggedIn = false;
        for (int attempts = 0; attempts < MAX_LOGIN_ATTEMPTS; attempts++) {
            System.out.print("Enter your username: ");
            String loginUsername = scanner.nextLine().trim();

            System.out.print("Enter your password: ");
            String loginPassword = scanner.nextLine().trim();

            String loginStatus = login.returnLoginStatus(loginUsername, loginPassword);
            System.out.println(loginStatus);

            if (loginStatus.startsWith("Welcome")) {
                loggedIn = true;
                break;
            } else {
                System.out.println("You have " + (MAX_LOGIN_ATTEMPTS - 1 - attempts) + " attempt(s) remaining.");
            }
        }

        if (!loggedIn) {
            System.out.println("Too many failed login attempts. Exiting...");
        }
    }

    // The Functional interface for input validation
    @FunctionalInterface
    interface InputValidator {
        boolean isValid(String input);
    }
}
    

