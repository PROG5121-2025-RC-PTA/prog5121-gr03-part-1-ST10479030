import org.json.simple.JSONObject;
import java.io.FileWriter;
import java.io.IOException;

public class JsonUtil {
    public static void writeToFile(JSONObject messageData) {
        try (FileWriter file = new FileWriter("stored_messages.json", true)) {
            file.write(messageData.toJSONString() + "\n");
            file.flush();
        } catch (IOException e) {
            System.out.println("An error occurred while writing the message to JSON.");
            e.printStackTrace();
        }
    }
}
