public class Login {
    private final String firstName;
    private final String lastName;
    private final String phoneNumber;
    private String username;
    private String password;

    // Constructor
    public Login(String firstName, String lastName, String phoneNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
    }

    // Method to check username validity
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Method to check password complexity
    public boolean checkPasswordComplexity(String password) {
        return password.length() >= 8 &&
               password.matches(".*[A-Z].*") &&
               password.matches(".*\\d.*") &&
               password.matches(".*[!@#$%^&*(),.?\":{}|<>].*");
    }

    // Method to register a user
    public String registerUser(String username, String password) {
        if (checkUserName(username) && checkPasswordComplexity(password)) {
            this.username = username;
            this.password = password;
            return "Registration successful!";
        } else {
            return "Registration failed. Invalid username or password.";
        }
    }

    // Method to validate login credentials
    public String returnLoginStatus(String username, String password) {
        if (this.username != null && this.password != null &&
            this.username.equals(username) && this.password.equals(password)) {
            return "Welcome " + this.firstName + " " + this.lastName + "!";
        } else {
            return "Invalid username or password.";
        }
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }
}
